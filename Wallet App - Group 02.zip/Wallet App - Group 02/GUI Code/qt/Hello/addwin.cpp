#include "addwin.h"
#include "ui_addwin.h"
#include "mainwindow.h"
#include<QMessageBox>

#include<stdio.h>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <windows.h>


using namespace std;

struct // structure for add/update/remove wallet info and transactions
{

    char name[50];
    char wallteNumber[50];
    char id[50];
    char amt[50];


}add, upd, check, rem, transaction;



AddWin::AddWin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddWin)
{
    ui->setupUi(this);
}

AddWin::~AddWin()
{
    delete ui;
}

void AddWin::on_pushButton_clicked()
{



    QString walletNumber= ui->lineEdit1->text();
    QString name= ui->lineEdit_2->text();
    QString studentID= ui->lineEdit_3->text();
    QString amountToDeposit= ui->lineEdit_4->text();


    string Wall=walletNumber.toStdString();

    for(int i=0;i<Wall.length();i++){
        add.wallteNumber[i]=Wall[i];
    }

    string Name=name.toStdString();

    for(int i=0;i<Wall.length();i++){
        add.name[i]=Name[i];
    }

    string Amt=amountToDeposit.toStdString();

    for(int i=0;i<Amt.length();i++){
        add.amt[i]=Amt[i];
    }

    string Cit=studentID.toStdString();

    for(int i=0;i<Cit.length();i++){
        add.id[i]=Cit[i];
    }




    FILE *ptr;

    ptr = fopen("record.dat", "a+");

    fprintf(ptr, "%s %s %s %s\n", add.name,add.wallteNumber,add.amt,add.id);

    fclose(ptr);





    QMessageBox::information(this,"Message","Wallet Created Successfully!");






}


void AddWin::on_pushButton_2_clicked()
{
    hide();
   // QApplication a(argc, argv);
    MainWindow w;
    w.show();


}


