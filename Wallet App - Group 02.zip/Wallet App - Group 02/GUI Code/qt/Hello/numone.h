#ifndef NUMONE_H
#define NUMONE_H

#include <QDialog>

namespace Ui {
class NumOne;
}

class NumOne : public QDialog
{
    Q_OBJECT

public:
    explicit NumOne(QWidget *parent = nullptr);
    ~NumOne();

private slots:


private:
    Ui::NumOne *ui;
};

#endif // NUMONE_H
