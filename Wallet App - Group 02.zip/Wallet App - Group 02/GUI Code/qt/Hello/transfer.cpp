#include "transfer.h"
#include "ui_transfer.h"
#include<QMessageBox>


#include<stdio.h>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <windows.h>


using namespace std;

struct // structure for add/update/remove wallet info and transactions
{

    char recipientName[50];
    char amt[50];
    char cat[50];
    char iD[50];


}add, upd, check, rem, transaction;

Transfer::Transfer(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Transfer)
{
    ui->setupUi(this);
}

Transfer::~Transfer()
{
    delete ui;
}

void Transfer::on_pushButton_clicked()
{
    QString recipient = ui->lineEdit->text();
    QString amount = ui->lineEdit_2->text();
    QString category = ui->lineEdit_3->text();
    QString id = ui->lineEdit_4->text();


    string Rec=recipient.toStdString();

    for(int i=0;i<Rec.length();i++){
        add.recipientName[i]=Rec[i];
    }

    string AMT=amount.toStdString();

    for(int i=0;i<AMT.length();i++){
        add.amt[i]=AMT[i];
    }

    string CAT=category.toStdString();

    for(int i=0;i<CAT.length();i++){
        add.cat[i]=CAT[i];
    }

    string ID=id.toStdString();

    for(int i=0;i<Rec.length();i++){
        add.iD[i]=ID[i];
    }



    FILE *ptr;

    ptr = fopen("trans.dat", "a+");

    fprintf(ptr, "%s %s %s %s\n", add.recipientName,add.amt,add.cat,add.iD);

    fclose(ptr);





    QMessageBox::information(this,"Message","Transaction Complete!");




}

