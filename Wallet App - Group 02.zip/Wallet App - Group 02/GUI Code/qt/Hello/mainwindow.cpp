#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "addwin.h"
#include "transfer.h"
//#include <QPixmap>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{


    ui->setupUi(this);

    this->setStyleSheet("background-color: #07e32f;");

    /*
    QPixmap pix("D:/fifa/a/teka.jpg");
    ui->piclabel->setPixmap(pix.scaled(300,300,Qt::KeepAspectRatio));
    */


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{


    adwin = new AddWin(this);
    adwin->show();


}





void MainWindow::on_pushButton_2_clicked()
{
    chek = new CheckWallet(this);
    chek->show();

}


void MainWindow::on_pushButton_3_clicked()
{
    erase = new Erase(this);
    erase->show();

}






void MainWindow::on_pushButton_4_clicked()
{
    trans = new Transfer(this);
    trans->show();


}


void MainWindow::on_pushButton_5_clicked()
{
    det = new Details(this);
    det->show();

}

