#ifndef CHECKWALLET_H
#define CHECKWALLET_H

#include <QDialog>

namespace Ui {
class CheckWallet;
}

class CheckWallet : public QDialog
{
    Q_OBJECT

public:
    explicit CheckWallet(QWidget *parent = nullptr);
    ~CheckWallet();

private slots:
    void on_pushButton_2_clicked();

private:
    Ui::CheckWallet *ui;
};

#endif // CHECKWALLET_H
