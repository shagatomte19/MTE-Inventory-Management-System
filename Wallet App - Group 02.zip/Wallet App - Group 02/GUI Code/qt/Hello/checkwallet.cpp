#include "checkwallet.h"
#include "ui_checkwallet.h"
#include "addwin.h"


#include<stdio.h>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <windows.h>

using namespace std;

struct // structure for add/update/remove wallet info and transactions
{

    char name[50];
    char wallteNumber[50];
    char id[50];
    char amt[50];


}add, upd, check, rem, transaction;

CheckWallet::CheckWallet(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CheckWallet)
{
    ui->setupUi(this);
}

CheckWallet::~CheckWallet()
{
    delete ui;
}

void CheckWallet::on_pushButton_2_clicked()
{


    FILE *ptr;
    ptr = fopen("record.dat", "r");

    QString walletNumber= ui->lineEdit1->text();

    string accountNumber=walletNumber.toStdString();




    while (fscanf(ptr,"%s %s %s %s",add.name,add.wallteNumber,add.amt,add.id)!=EOF){

        cout << add.name <<" "<<add.wallteNumber <<" "<< add.amt <<" "<< add.id <<'\n';
               if(add.wallteNumber==accountNumber){
                   cout <<"found" <<'\n';
                     cout <<"hi"<<'\n';
                    ui->textBrowser->setText(add.wallteNumber);
                    ui->textBrowser_2->setText(add.name);
                    ui->textBrowser_3->setText(add.id);
                    ui->textBrowser_4->setText(add.amt);
               }

    }



       fclose(ptr);





}

