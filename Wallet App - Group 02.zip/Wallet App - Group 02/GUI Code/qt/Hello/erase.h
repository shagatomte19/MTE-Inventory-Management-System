#ifndef ERASE_H
#define ERASE_H

#include <QDialog>

namespace Ui {
class Erase;
}

class Erase : public QDialog
{
    Q_OBJECT

public:
    explicit Erase(QWidget *parent = nullptr);
    ~Erase();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Erase *ui;
};

#endif // ERASE_H
