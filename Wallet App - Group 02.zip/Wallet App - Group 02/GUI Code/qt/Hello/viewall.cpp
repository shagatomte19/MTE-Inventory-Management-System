#include "viewall.h"
#include "ui_viewall.h"


#include<stdio.h>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <windows.h>

using namespace std;

ViewAll::ViewAll(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ViewAll)
{
    ui->setupUi(this);
}

ViewAll::~ViewAll()
{
    delete ui;
}

void ViewAll::on_pushButton_clicked()
{





}

