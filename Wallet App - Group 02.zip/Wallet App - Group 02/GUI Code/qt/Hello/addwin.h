#ifndef ADDWIN_H
#define ADDWIN_H

#include <QDialog>

namespace Ui {
class AddWin;
}

class AddWin : public QDialog
{
    Q_OBJECT

public:
    explicit AddWin(QWidget *parent = nullptr);
    ~AddWin();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();



private:
    Ui::AddWin *ui;
};

#endif // ADDWIN_H
