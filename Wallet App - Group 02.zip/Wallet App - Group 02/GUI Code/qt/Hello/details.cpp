#include "details.h"
#include "ui_details.h"

#include<stdio.h>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <windows.h>

using namespace std;

struct // structure for add/update/remove wallet info and transactions
{

    char recipientName[50];
    char amt[50];
    char cat[50];
    char iD[50];



}add, upd, check, rem, transaction;



Details::Details(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Details)
{
    ui->setupUi(this);
}

Details::~Details()
{
    delete ui;
}

void Details::on_pushButton_clicked()
{


    FILE *ptr;
    ptr = fopen("trans.dat", "r");

    QString rid= ui->lineEdit1->text();

    string recipID=rid.toStdString();


    while (fscanf(ptr,"%s %s %s %s",add.recipientName,add.amt,add.cat,add.iD)!=EOF){

        //cout << add.name <<" "<<add.wallteNumber <<" "<< add.amt <<" "<< add.citizenship <<'\n';
               if(add.iD==recipID){
                   cout <<"found" <<'\n';
                     cout <<"hi"<<'\n';
                    ui->textBrowser->setText(add.recipientName);
                    ui->textBrowser_2->setText(add.amt);
                    ui->textBrowser_3->setText(add.cat);

               }

    }



       fclose(ptr);



}

