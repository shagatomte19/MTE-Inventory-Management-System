#ifndef TRAN_H
#define TRAN_H

#include <QDialog>

namespace Ui {
class Tran;
}

class Tran : public QDialog
{
    Q_OBJECT

public:
    explicit Tran(QWidget *parent = nullptr);
    ~Tran();

private:
    Ui::Tran *ui;
};

#endif // TRAN_H
