#include "erase.h"
#include "ui_erase.h"

#include<stdio.h>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <windows.h>

#include<QMessageBox>

using namespace std;

struct // structure for add/update/remove wallet info and transactions
{

    char name[50];
    char wallteNumber[50];
    char id[50];
    char amt[50];


}add, upd, check, rem, transaction;

Erase::Erase(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Erase)
{
    ui->setupUi(this);
}

Erase::~Erase()
{
    delete ui;
}



void Erase::on_pushButton_clicked()
{
    FILE *old, *newrec;
    old = fopen("record.dat", "r");
    newrec = fopen("new.dat", "w");

    QString walletNumber= ui->lineEdit->text();

    string accountNumber=walletNumber.toStdString();



    bool found=false;


    while (fscanf(old, "%s %s %s %s",add.name,add.wallteNumber,add.amt,add.id) != EOF)
        {
            if (add.wallteNumber != accountNumber)
                fprintf(newrec, "%s %s %s %s",add.name,add.wallteNumber,add.amt,add.id );

            else
            {
                found=true;
                printf("\nRecord deleted successfully!\n");
            }
        }
        fclose(old);
        fclose(newrec);
        remove("record.dat");
        rename("new.dat", "record.dat");

        if(found){
            QMessageBox::information(this,"Message","Wallet Deleted Successfully!");
        }else{
            QMessageBox::information(this,"Message","Wallet Not found!");

        }

}

