#ifndef VIEWALL_H
#define VIEWALL_H

#include <QDialog>
#include <QtCore>
#include <QtGui>

namespace Ui {
class ViewAll;
}

class ViewAll : public QDialog
{
    Q_OBJECT

public:
    explicit ViewAll(QWidget *parent = nullptr);
    ~ViewAll();

private slots:
    void on_pushButton_clicked();

private:
    Ui::ViewAll *ui;
    QStringListModel *model;
};

#endif // VIEWALL_H
