#include "numone.h"
#include "ui_numone.h"


#include<stdio.h>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <windows.h>

using namespace std;

NumOne::NumOne(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::NumOne)
{
    ui->setupUi(this);
}

NumOne::~NumOne()
{
    delete ui;
}



