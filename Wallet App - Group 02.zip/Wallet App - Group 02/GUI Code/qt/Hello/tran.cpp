#include "tran.h"
#include "ui_tran.h"

Tran::Tran(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Tran)
{
    ui->setupUi(this);
}

Tran::~Tran()
{
    delete ui;
}
