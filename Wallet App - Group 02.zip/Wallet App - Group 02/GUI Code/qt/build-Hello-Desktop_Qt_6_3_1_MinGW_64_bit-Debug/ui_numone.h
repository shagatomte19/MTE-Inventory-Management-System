/********************************************************************************
** Form generated from reading UI file 'numone.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NUMONE_H
#define UI_NUMONE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_NumOne
{
public:
    QPushButton *pushButton;

    void setupUi(QDialog *NumOne)
    {
        if (NumOne->objectName().isEmpty())
            NumOne->setObjectName(QString::fromUtf8("NumOne"));
        NumOne->resize(533, 408);
        pushButton = new QPushButton(NumOne);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(160, 200, 91, 31));

        retranslateUi(NumOne);

        QMetaObject::connectSlotsByName(NumOne);
    } // setupUi

    void retranslateUi(QDialog *NumOne)
    {
        NumOne->setWindowTitle(QCoreApplication::translate("NumOne", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("NumOne", "PushButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NumOne: public Ui_NumOne {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NUMONE_H
