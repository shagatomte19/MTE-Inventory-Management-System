/********************************************************************************
** Form generated from reading UI file 'details.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DETAILS_H
#define UI_DETAILS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_Details
{
public:
    QLabel *label_2;
    QLineEdit *lineEdit1;
    QPushButton *pushButton;
    QTextBrowser *textBrowser;
    QTextBrowser *textBrowser_2;
    QTextBrowser *textBrowser_3;
    QLabel *label_3;
    QLabel *label;
    QLabel *label_4;

    void setupUi(QDialog *Details)
    {
        if (Details->objectName().isEmpty())
            Details->setObjectName(QString::fromUtf8("Details"));
        Details->resize(432, 346);
        label_2 = new QLabel(Details);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 50, 121, 16));
        lineEdit1 = new QLineEdit(Details);
        lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
        lineEdit1->setGeometry(QRect(180, 50, 131, 22));
        pushButton = new QPushButton(Details);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(200, 90, 91, 24));
        textBrowser = new QTextBrowser(Details);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(180, 150, 171, 31));
        textBrowser_2 = new QTextBrowser(Details);
        textBrowser_2->setObjectName(QString::fromUtf8("textBrowser_2"));
        textBrowser_2->setGeometry(QRect(180, 200, 171, 31));
        textBrowser_3 = new QTextBrowser(Details);
        textBrowser_3->setObjectName(QString::fromUtf8("textBrowser_3"));
        textBrowser_3->setGeometry(QRect(180, 250, 171, 31));
        label_3 = new QLabel(Details);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(50, 150, 101, 21));
        label = new QLabel(Details);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 210, 49, 16));
        label_4 = new QLabel(Details);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(70, 260, 49, 16));

        retranslateUi(Details);

        QMetaObject::connectSlotsByName(Details);
    } // setupUi

    void retranslateUi(QDialog *Details)
    {
        Details->setWindowTitle(QCoreApplication::translate("Details", "Dialog", nullptr));
        label_2->setText(QCoreApplication::translate("Details", "Recipient's Account ID", nullptr));
        pushButton->setText(QCoreApplication::translate("Details", "Get Details!", nullptr));
        label_3->setText(QCoreApplication::translate("Details", "Recipient Name", nullptr));
        label->setText(QCoreApplication::translate("Details", "Amount", nullptr));
        label_4->setText(QCoreApplication::translate("Details", "Category", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Details: public Ui_Details {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DETAILS_H
