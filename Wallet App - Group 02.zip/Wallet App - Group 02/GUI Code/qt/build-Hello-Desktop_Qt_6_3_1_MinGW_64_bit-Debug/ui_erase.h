/********************************************************************************
** Form generated from reading UI file 'erase.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ERASE_H
#define UI_ERASE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Erase
{
public:
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLabel *label;

    void setupUi(QDialog *Erase)
    {
        if (Erase->objectName().isEmpty())
            Erase->setObjectName(QString::fromUtf8("Erase"));
        Erase->resize(367, 190);
        pushButton = new QPushButton(Erase);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(40, 80, 75, 24));
        lineEdit = new QLineEdit(Erase);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(150, 80, 113, 22));
        label = new QLabel(Erase);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 30, 201, 16));

        retranslateUi(Erase);

        QMetaObject::connectSlotsByName(Erase);
    } // setupUi

    void retranslateUi(QDialog *Erase)
    {
        Erase->setWindowTitle(QCoreApplication::translate("Erase", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("Erase", "Erase", nullptr));
        label->setText(QCoreApplication::translate("Erase", "Enter the account number", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Erase: public Ui_Erase {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ERASE_H
