/********************************************************************************
** Form generated from reading UI file 'checkwallet.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHECKWALLET_H
#define UI_CHECKWALLET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_CheckWallet
{
public:
    QGroupBox *groupBox;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QTextBrowser *textBrowser;
    QTextBrowser *textBrowser_2;
    QTextBrowser *textBrowser_3;
    QTextBrowser *textBrowser_4;
    QLineEdit *lineEdit1;
    QLabel *label_5;
    QPushButton *pushButton_2;

    void setupUi(QDialog *CheckWallet)
    {
        if (CheckWallet->objectName().isEmpty())
            CheckWallet->setObjectName(QString::fromUtf8("CheckWallet"));
        CheckWallet->resize(492, 431);
        groupBox = new QGroupBox(CheckWallet);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(40, 80, 391, 341));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 90, 111, 16));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 150, 49, 16));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 210, 111, 16));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(20, 260, 111, 16));
        textBrowser = new QTextBrowser(groupBox);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(190, 90, 171, 31));
        textBrowser_2 = new QTextBrowser(groupBox);
        textBrowser_2->setObjectName(QString::fromUtf8("textBrowser_2"));
        textBrowser_2->setGeometry(QRect(190, 150, 171, 31));
        textBrowser_3 = new QTextBrowser(groupBox);
        textBrowser_3->setObjectName(QString::fromUtf8("textBrowser_3"));
        textBrowser_3->setGeometry(QRect(190, 210, 171, 31));
        textBrowser_4 = new QTextBrowser(groupBox);
        textBrowser_4->setObjectName(QString::fromUtf8("textBrowser_4"));
        textBrowser_4->setGeometry(QRect(190, 270, 171, 31));
        lineEdit1 = new QLineEdit(CheckWallet);
        lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
        lineEdit1->setGeometry(QRect(200, 30, 113, 22));
        label_5 = new QLabel(CheckWallet);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(50, 30, 141, 16));
        pushButton_2 = new QPushButton(CheckWallet);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(340, 30, 75, 24));

        retranslateUi(CheckWallet);

        QMetaObject::connectSlotsByName(CheckWallet);
    } // setupUi

    void retranslateUi(QDialog *CheckWallet)
    {
        CheckWallet->setWindowTitle(QCoreApplication::translate("CheckWallet", "Dialog", nullptr));
        groupBox->setTitle(QCoreApplication::translate("CheckWallet", "Wallet Information", nullptr));
        label->setText(QCoreApplication::translate("CheckWallet", "Wallet Number", nullptr));
        label_2->setText(QCoreApplication::translate("CheckWallet", "Name", nullptr));
        label_3->setText(QCoreApplication::translate("CheckWallet", "Citizenship Number", nullptr));
        label_4->setText(QCoreApplication::translate("CheckWallet", "Amount to Deposit", nullptr));
        label_5->setText(QCoreApplication::translate("CheckWallet", "Enter The Wallet Number :", nullptr));
        pushButton_2->setText(QCoreApplication::translate("CheckWallet", "Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CheckWallet: public Ui_CheckWallet {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHECKWALLET_H
