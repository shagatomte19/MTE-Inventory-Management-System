/********************************************************************************
** Form generated from reading UI file 'transfer.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRANSFER_H
#define UI_TRANSFER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Transfer
{
public:
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *lineEdit_4;
    QLabel *label_4;

    void setupUi(QDialog *Transfer)
    {
        if (Transfer->objectName().isEmpty())
            Transfer->setObjectName(QString::fromUtf8("Transfer"));
        Transfer->resize(480, 332);
        lineEdit = new QLineEdit(Transfer);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(50, 50, 113, 22));
        pushButton = new QPushButton(Transfer);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(170, 230, 75, 24));
        lineEdit_2 = new QLineEdit(Transfer);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(50, 90, 113, 22));
        lineEdit_3 = new QLineEdit(Transfer);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(50, 130, 113, 22));
        label = new QLabel(Transfer);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(180, 90, 49, 16));
        label_2 = new QLabel(Transfer);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(180, 170, 121, 16));
        label_3 = new QLabel(Transfer);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(180, 50, 101, 21));
        lineEdit_4 = new QLineEdit(Transfer);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(50, 170, 113, 22));
        label_4 = new QLabel(Transfer);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(180, 130, 121, 16));

        retranslateUi(Transfer);

        QMetaObject::connectSlotsByName(Transfer);
    } // setupUi

    void retranslateUi(QDialog *Transfer)
    {
        Transfer->setWindowTitle(QCoreApplication::translate("Transfer", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("Transfer", "Send", nullptr));
        label->setText(QCoreApplication::translate("Transfer", "Amount", nullptr));
        label_2->setText(QCoreApplication::translate("Transfer", "Recipient's Account ID", nullptr));
        label_3->setText(QCoreApplication::translate("Transfer", "Recipient Name", nullptr));
        label_4->setText(QCoreApplication::translate("Transfer", "Category", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Transfer: public Ui_Transfer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRANSFER_H
