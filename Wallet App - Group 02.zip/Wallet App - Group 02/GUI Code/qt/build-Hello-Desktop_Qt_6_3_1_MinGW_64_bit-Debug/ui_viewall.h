/********************************************************************************
** Form generated from reading UI file 'viewall.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIEWALL_H
#define UI_VIEWALL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ViewAll
{
public:
    QGroupBox *groupBox;
    QPushButton *pushButton;
    QListView *listView;

    void setupUi(QDialog *ViewAll)
    {
        if (ViewAll->objectName().isEmpty())
            ViewAll->setObjectName(QString::fromUtf8("ViewAll"));
        ViewAll->resize(562, 444);
        groupBox = new QGroupBox(ViewAll);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(60, 60, 461, 341));
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(170, 280, 75, 24));
        listView = new QListView(groupBox);
        listView->setObjectName(QString::fromUtf8("listView"));
        listView->setGeometry(QRect(70, 40, 256, 192));

        retranslateUi(ViewAll);

        QMetaObject::connectSlotsByName(ViewAll);
    } // setupUi

    void retranslateUi(QDialog *ViewAll)
    {
        ViewAll->setWindowTitle(QCoreApplication::translate("ViewAll", "Dialog", nullptr));
        groupBox->setTitle(QCoreApplication::translate("ViewAll", "GroupBox", nullptr));
        pushButton->setText(QCoreApplication::translate("ViewAll", "Load", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ViewAll: public Ui_ViewAll {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIEWALL_H
