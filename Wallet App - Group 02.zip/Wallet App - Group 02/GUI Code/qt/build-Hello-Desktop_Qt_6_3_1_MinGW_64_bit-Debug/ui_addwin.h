/********************************************************************************
** Form generated from reading UI file 'addwin.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDWIN_H
#define UI_ADDWIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_AddWin
{
public:
    QGroupBox *groupBox;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit1;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLabel *label_3;
    QLabel *label_4;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton_3;
    QRadioButton *radioButton_4;
    QLabel *label_6;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *AddWin)
    {
        if (AddWin->objectName().isEmpty())
            AddWin->setObjectName(QString::fromUtf8("AddWin"));
        AddWin->resize(462, 421);
        groupBox = new QGroupBox(AddWin);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(30, 20, 391, 361));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 40, 111, 16));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 70, 49, 16));
        lineEdit1 = new QLineEdit(groupBox);
        lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
        lineEdit1->setGeometry(QRect(150, 40, 113, 22));
        lineEdit_2 = new QLineEdit(groupBox);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(150, 70, 113, 22));
        lineEdit_3 = new QLineEdit(groupBox);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(150, 110, 113, 22));
        lineEdit_4 = new QLineEdit(groupBox);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(150, 150, 113, 22));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 110, 111, 16));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(20, 150, 111, 16));
        radioButton = new QRadioButton(groupBox);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(150, 200, 89, 20));
        radioButton_2 = new QRadioButton(groupBox);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(150, 220, 89, 20));
        radioButton_3 = new QRadioButton(groupBox);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));
        radioButton_3->setGeometry(QRect(150, 240, 89, 20));
        radioButton_4 = new QRadioButton(groupBox);
        radioButton_4->setObjectName(QString::fromUtf8("radioButton_4"));
        radioButton_4->setGeometry(QRect(150, 260, 89, 20));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(20, 200, 91, 16));
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(150, 320, 75, 24));
        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(300, 20, 75, 24));

        retranslateUi(AddWin);

        QMetaObject::connectSlotsByName(AddWin);
    } // setupUi

    void retranslateUi(QDialog *AddWin)
    {
        AddWin->setWindowTitle(QCoreApplication::translate("AddWin", "Dialog", nullptr));
        groupBox->setTitle(QCoreApplication::translate("AddWin", "Add Information", nullptr));
        label->setText(QCoreApplication::translate("AddWin", "Wallet Number", nullptr));
        label_2->setText(QCoreApplication::translate("AddWin", "Name", nullptr));
        label_3->setText(QCoreApplication::translate("AddWin", "Student ID", nullptr));
        label_4->setText(QCoreApplication::translate("AddWin", "Amount to Deposit ", nullptr));
        radioButton->setText(QCoreApplication::translate("AddWin", "Personal", nullptr));
        radioButton_2->setText(QCoreApplication::translate("AddWin", "Saving", nullptr));
        radioButton_3->setText(QCoreApplication::translate("AddWin", "Daily", nullptr));
        radioButton_4->setText(QCoreApplication::translate("AddWin", "Monthly", nullptr));
        label_6->setText(QCoreApplication::translate("AddWin", "Type Of Wallet :", nullptr));
        pushButton->setText(QCoreApplication::translate("AddWin", "Create", nullptr));
        pushButton_2->setText(QCoreApplication::translate("AddWin", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddWin: public Ui_AddWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDWIN_H
