
import numpy as np
import simpleaudio as sa

try:
    import winsound
except ImportError:
    import os
    def playsound(x,z):
        frequency = x # Our played note will be 440 Hz
        fs = 44100  # 44100 samples per second
        seconds = z  # Note duration of 3 seconds

        # Generate array with seconds*sample_rate steps,   ranging between 0 and seconds
        t = np.linspace(0, seconds, seconds * fs, False)

        # Generate a 440 Hz sine wave
        note = np.sin(frequency * t * 2 * np.pi)

         # Ensure that highest value is in 16-bit range
        audio = note * (2**15 - 1) / np.max(np.abs(note))
         # Convert to 16-bit data
        audio = audio.astype(np.int16)

         # Start playback
        play_obj = sa.play_buffer(audio, 1, 2, fs)

         # Wait for playback to finish before exiting
        play_obj.wait_done()
else:
    def playsound(frequency,duration):
        winsound.Beep(frequency,duration)
import time
class Sound:

    def __init__(self,freq):
        self.frequency = freq
        self.dotDuration = 1
        self.dashDuration = 2
        self.delaydurationwrd = .5
        self.delaydurationsen = 1

    def signSound(self,ch):
        if ch == '.':
            playsound(self.frequency, self.dotDuration)
        elif ch == '-':
            playsound(self.frequency, self.dashDuration)   
        time.sleep(1)

    def charSound(self,wrd):
        charr = list(wrd)
        print(charr)
        for i in range(len(wrd)):
            self.signSound(charr[i])

    def wrdSound(self,wrd):
        wrdarr = wrd.split(' ')
        print(wrdarr)
        for i in range(len(wrdarr)):
            self.charSound(wrdarr[i])
            time.sleep(self.delaydurationwrd)

    def senSound(self,wrd):
        wrdarr = wrd.split('   ')
        print(wrdarr)
        for i in range(len(wrdarr)):
            self.wrdSound(wrdarr[i])
            time.sleep(self.delaydurationsen)



if __name__=="__main__":
    fq = 4000
    du = 1000
    sound = Sound(fq)
    #sound.charSound('.-..')
    wrd = '.... . .-.. .-.. ---   .-- --- .-. .-.. -..'
    sound.senSound(wrd)
    arr = wrd.split(' ')
    print(arr)
    print("Hello")
