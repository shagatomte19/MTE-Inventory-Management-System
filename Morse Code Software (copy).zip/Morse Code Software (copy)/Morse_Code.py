# -*- coding: utf-8 -*-
"""
Created on July 25, 2022
File: Morse code Encoder and Decoder
@author: Group-8
"""
class morse:
    
    def __init__(self,file_name):
        try:        
            self.file = open(file_name,'r')
            print('Morse File Founded :) ')
            l_a = [chr(i) for i in range(65,92)]
            l_b = [i for i in range(1,27)]
            self.alphabet = {i:j for i,j in zip((l_a),l_b)}
    
            for i in range(11):    
                self.alphabet[str(i)] = i            
            
        except FileNotFoundError:
            print('Morse file is not in the name folder or file not found')
            quit()
    
    
    def encode_char(self,var):
        self.file.seek(0,0)
        return self.read_file_line_by_num(self.alphabet[var]).split('  ')[1].strip('\n')
        
        
    def encode_word(self,st):
        line = ''
        i = 0
        for items in st:
            line = line + (str(self.encode_char(items)))+' '
        return line
    
    
    def encode_sentence(self,sen):
        line = ''        
        for items in sen.split(' '):
            line = line + self.encode_word(items)+'   '
        return line
    
    
    def decode_char(self,ch):
        for i in range(36):
            data = self.read_file_line_by_num(i).split('  ')
            if data[1].strip('\n').__eq__(ch):
                return data[0]    
        return #'No match found'
    
    
    def decode_word(self,word):
        wd = ''
        for item in word.split(' '):
            wd = wd+self.decode_char(item)           
        return wd
    
    
    def decode_sen(self,sen):
        sn = ''
        for item in sen.split('   '):
            sn = sn+self.decode_word(item)+' '           
        return sn
    
    
    
    def read_file_line_by_num(self,line_num):
        self.file.seek(0,0)
        for i in range(line_num-1):
            self.file.readline()
        return self.file.readline()
        

    def __del__(self):
        self.file.close()
        del self.file
        print('File Closed')
       
        
        
if __name__=="__main__": 
    morse_code = morse('morse.txt')
    #str_in = input('Enter your input sentence: ') 
    #print()
    '''for items in str_in:
        print(morse_code.encode_char(items),end='')'''
    #a = morse_code.read_file_line_by_num(2).split(',')
    #print(a[1].strip('\n'))
    print(morse_code.encode_sentence('SOS'))
    print(morse_code.decode_sen('.... . .-.. .-.. ---   .-- --- .-. .-.. -..'))
    #del morse_code
